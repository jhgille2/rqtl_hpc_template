library(testthat)
library(fnmate)

test_check("fnmate")
