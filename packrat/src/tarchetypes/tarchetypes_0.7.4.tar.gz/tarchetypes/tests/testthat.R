library(testthat)
library(tarchetypes)

test_check("tarchetypes")
