#' @importFrom utils globalVariables
globalVariables(c(".", ".."))

bquote_compile <- import_future("bquote_compile")
bquote_apply <- import_future("bquote_apply")
